<?php
/*
Name: PageMotor Architect AI: DeepSeek
Author: Elmspark
Description: Drive PageMotor's Architect AI agent with DeepSeek. Adds DeepSeek as a first-class provider with a curated model list (DeepSeek-V4 Flash and Pro); paste your DeepSeek API key and go. Flash is the cheap workhorse and is plenty for most Architect jobs; Pro trades cost for stronger reasoning. Billed per 1M tokens in USD. Requires the Architect AI: OpenAI-Compatible base plugin (it carries the shared adapter).
Version: 1.0.0
Requires: 0.4
Class: Architect_AI_DeepSeek
Model: Architect_AI_OpenAI
Docs: https://pagemotor.com/plugins/ai/architect/deepseek/
License: OpenAttribution

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Architect AI: DeepSeek Plugin
 * @author		Elmspark
 * @copyright 	Copyright (c) 2026, Elmspark Consultants
 * @license		OpenAttribution
 * @since		0.4
 */

// Thin curated provider on the shared OpenAI-compatible base. The base class
// (Architect_AI_OpenAI) is defined by the architect-ai-openai plugin, which must
// be active; the `Model: Architect_AI_OpenAI` header makes PageMotor load this
// plugin only after that class exists. All behaviour (adapter, process, request,
// prompt JS) is inherited; this file is just configuration.
class Architect_AI_DeepSeek extends Architect_AI_OpenAI {
	public $title = 'DeepSeek for Architect AI';
	public $ai = 'DeepSeek';
	public $agent = 'Architect';
	protected $default_base_url = 'https://api.deepseek.com';
	// DeepSeek-V4 ids, verified live against /models 2026-06-18. Both support the
	// tool-calling Architect needs. The legacy deepseek-chat / deepseek-reasoner ids
	// (still aliased today) retire on 24 July 2026, folding into V4 Flash's
	// non-thinking / thinking modes, so the curated list carries the V4 ids only;
	// the generic OpenAI-Compatible provider can still reach any other id by hand.
	public $models = [
		'DeepSeek Flash (recommended)'  => 'deepseek-v4-flash',
		'DeepSeek Pro (stronger)'       => 'deepseek-v4-pro'];
	public $model = 'DeepSeek Flash (recommended)';
}
