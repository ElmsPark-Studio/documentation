<?php
/*
Name: PageMotor Architect AI: xAI Grok
Author: Elmspark
Description: Drive PageMotor's Architect AI agent with xAI Grok models. Adds Grok as a first-class provider with a curated model list; paste your xAI API key and go. Requires the Architect AI: OpenAI-Compatible base plugin (it carries the shared adapter).
Version: 1.0.0
Requires: 0.4
Class: Architect_AI_Grok
Model: Architect_AI_OpenAI
Docs: https://pagemotor.com/plugins/ai/architect/grok/
License: OpenAttribution

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Architect AI: xAI Grok Plugin
 * @author		Elmspark
 * @copyright 	Copyright (c) 2026, Elmspark Consultants
 * @license		OpenAttribution
 * @since		0.4
 */

// Thin curated provider on the shared OpenAI-compatible base. See architect-ai-
// deepseek for the pattern.
//
// !! UNVERIFIED + LIKELY STALE !!  These Grok 2-era ids have NOT been live-checked
// (no funded xAI key yet), and grok-2-1212 is a Dec-2024 dated snapshot — by 2026
// xAI's current line is Grok 3 / Grok 4, so the curated default below may 404 on
// first use. Before relying on this provider: GET https://api.x.ai/v1/models with a
// real key and replace $models with the live current ids (likely grok-4 as the
// strong default and grok-3 / grok-3-mini as the cheaper option), then set $model.
// Until then, the generic OpenAI-Compatible provider can reach any Grok id by hand.
class Architect_AI_Grok extends Architect_AI_OpenAI {
	public $title = 'xAI Grok for Architect AI';
	public $ai = 'xAI Grok';
	public $agent = 'Architect';
	protected $default_base_url = 'https://api.x.ai/v1';
	public $models = [
		'Grok (latest)' => 'grok-2-latest',
		'Grok 2'        => 'grok-2-1212'];
	public $model = 'Grok (latest)';
}
