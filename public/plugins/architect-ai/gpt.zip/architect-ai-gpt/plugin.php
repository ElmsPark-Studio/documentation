<?php
/*
Name: PageMotor Architect AI: OpenAI GPT
Author: Elmspark
Description: Drive PageMotor's Architect AI agent with OpenAI GPT models. Adds OpenAI as a first-class provider with a curated model list; paste your OpenAI API key and go. Note: the Architect system prompt is large (tens of thousands of tokens), so gpt-4o / gpt-4.1 can hit the per-minute token (TPM) rate limit on new or low-tier OpenAI accounts; gpt-4o-mini has far more TPM headroom and is the default for that reason. Requires the Architect AI: OpenAI-Compatible base plugin (it carries the shared adapter).
Version: 1.0.0
Requires: 0.4
Class: Architect_AI_GPT
Model: Architect_AI_OpenAI
Docs: https://pagemotor.com/plugins/ai/architect/gpt/
License: OpenAttribution

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Architect AI: OpenAI GPT Plugin
 * @author		Elmspark
 * @copyright 	Copyright (c) 2026, Elmspark Consultants
 * @license		OpenAttribution
 * @since		0.4
 */

// Thin curated provider on the shared OpenAI-compatible base. See architect-ai-
// deepseek for the pattern. Model ids change often; edit $models here when OpenAI
// revises its line-up (or use the generic OpenAI-Compatible provider for any id
// not listed).
class Architect_AI_GPT extends Architect_AI_OpenAI {
	public $title = 'OpenAI GPT for Architect AI';
	public $ai = 'OpenAI GPT';
	public $agent = 'Architect';
	protected $default_base_url = 'https://api.openai.com/v1';
	// All three verified live (tool-calling OK) against /v1/chat/completions
	// 2026-06-18. gpt-4o-mini is the default: it has the TPM headroom for the large
	// Architect prompt on low-tier accounts (gpt-4o / gpt-4.1 can 429 there). gpt-4o
	// gives more reliable structured output if your account tier allows it.
	public $models = [
		'GPT-4o mini (recommended)' => 'gpt-4o-mini',
		'GPT-4o (stronger)'         => 'gpt-4o',
		'GPT-4.1 (stronger)'        => 'gpt-4.1'];
	public $model = 'GPT-4o mini (recommended)';
}
