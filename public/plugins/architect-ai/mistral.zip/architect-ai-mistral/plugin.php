<?php
/*
Name: PageMotor Architect AI: Mistral
Author: Elmspark
Description: Drive PageMotor's Architect AI agent with Mistral models via Mistral's OpenAI-compatible endpoint. Adds Mistral as a first-class provider with a curated model list; paste your Mistral API key and go. Requires the Architect AI: OpenAI-Compatible base plugin (it carries the shared adapter).
Version: 1.0.0
Requires: 0.4
Class: Architect_AI_Mistral
Model: Architect_AI_OpenAI
Docs: https://pagemotor.com/plugins/ai/architect/mistral/
License: OpenAttribution

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Architect AI: Mistral Plugin
 * @author		Elmspark
 * @copyright 	Copyright (c) 2026, Elmspark Consultants
 * @license		OpenAttribution
 * @since		0.4
 */

// Thin curated provider on the shared OpenAI-compatible base. See architect-ai-
// deepseek for the pattern. The `-latest` aliases are the stable choice; edit
// $models here for pinned versions (or use the generic OpenAI-Compatible provider
// for any id not listed).
class Architect_AI_Mistral extends Architect_AI_OpenAI {
	public $title = 'Mistral for Architect AI';
	public $ai = 'Mistral';
	public $agent = 'Architect';
	protected $default_base_url = 'https://api.mistral.ai/v1';
	// NOT live-certified (no funded Mistral key yet). The `-latest` aliases are the
	// stable choice and should track current; verify tool-calling with a key before
	// relying on them. Large is the default for tool-calling reliability; Small is
	// the cheaper option.
	public $models = [
		'Mistral Large (recommended)' => 'mistral-large-latest',
		'Mistral Small (cheaper)'     => 'mistral-small-latest'];
	public $model = 'Mistral Large (recommended)';
}
