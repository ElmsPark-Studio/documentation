<?php
/**
 * PageMotor Architect AI: OpenAI-Compatible Adapter
 *
 * Format mapping between PageMotor's provider-neutral inputs and the OpenAI
 * Chat Completions wire shape. This is the technical heart of multi-provider
 * support: one adapter plus an editable Base URL reaches GPT, DeepSeek, Grok,
 * Mistral, Groq, OpenRouter, Together, Fireworks, local Ollama/LM Studio/vLLM,
 * and Gemini's OpenAI-compatible endpoint.
 *
 * Two gotchas this adapter pins down (per the build spec):
 *   1. OpenAI returns tool-call arguments as a JSON STRING, not an object.
 *      parse_response() json_decodes them before they reach dispatch.
 *   2. The tool-schema BODY is identical across formats; only the outer wrapper
 *      differs. The re-wrap lives in tools.php (PM_AI_OpenAI_Tools), so this
 *      adapter only handles request assembly and response normalisation.
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Architect AI: OpenAI-Compatible Plugin
 * @author		Elmspark
 * @copyright 	Copyright (c) 2026, Elmspark Consultants
 * @license		OpenAttribution
 * @since		0.4
 */
class PM_AI_OpenAI_Adapter {

	// Build an OpenAI Chat Completions request body from neutral inputs.
	//   $args: model (string), system (string), prompt (string),
	//          tools (array, already in OpenAI function shape), max_tokens (int).
	// The system prompt becomes messages[0]; the user turn becomes messages[1].
	public function build_request($args = []) {
		$model = !empty($args['model']) ? $args['model'] : '';
		$system = isset($args['system']) ? (string) $args['system'] : '';
		$prompt = isset($args['prompt']) ? (string) $args['prompt'] : '';
		$tools = !empty($args['tools']) && is_array($args['tools']) ? $args['tools'] : [];
		$max_tokens = !empty($args['max_tokens']) ? (int) $args['max_tokens'] : 8192;
		$messages = [];
		if ($system !== '')
			$messages[] = [
				'role' => 'system',
				'content' => $system];
		$messages[] = [
			'role' => 'user',
			'content' => $prompt];
		$body = [
			'model' => $model,
			'max_tokens' => $max_tokens,
			'messages' => $messages];
		if (!empty($tools)) {
			$body['tools'] = $tools;
			$body['tool_choice'] = 'auto';
		}
		return $body;
	}

	// Normalise an OpenAI Chat Completions response into a neutral shape:
	//   ['type' => 'tool_calls', 'calls' => [['id', 'name', 'input' => array], ...]]
	//   ['type' => 'text', 'text' => '<reply>']
	// Tool calls are recognised whenever message.tool_calls is present, not only
	// when finish_reason == 'tool_calls' — some OpenAI-compatible providers report
	// finish_reason 'stop' alongside a tool call.
	public function parse_response($response) {
		$choice = !empty($response['choices'][0]) ? $response['choices'][0] : [];
		$message = !empty($choice['message']) ? $choice['message'] : [];
		$finish = !empty($choice['finish_reason']) ? $choice['finish_reason'] : '';
		if (!empty($message['tool_calls']) && is_array($message['tool_calls'])) {
			$calls = [];
			foreach ($message['tool_calls'] as $call) {
				if (empty($call['function']['name']))
					continue;
				$raw = isset($call['function']['arguments']) ? $call['function']['arguments'] : '';
				// OpenAI hands arguments back as a JSON string; Anthropic hands an
				// object. Decode the string so dispatch always receives an array.
				if (is_string($raw)) {
					$input = json_decode($raw, true);
					// A NON-EMPTY arguments string that fails to decode means the model
					// was cut off mid-tool-call (finish_reason 'length') and the JSON is
					// truncated. Surface that as an explicit error rather than coercing to
					// an empty [] — an empty input flows through create_content as a
					// misleading "no content supplied" failure, masking the real cause
					// (token limit). A legitimate no-arg call sends "{}", which decodes to
					// [] with NO json error, so this guard fires only on real truncation.
					if ($raw !== '' && $input === null && json_last_error() !== JSON_ERROR_NONE)
						return [
							'type' => 'truncated',
							'finish_reason' => $finish];
					if (!is_array($input))
						$input = [];
				}
				else
					$input = is_array($raw) ? $raw : [];
				$calls[] = [
					'id' => !empty($call['id']) ? $call['id'] : '',
					'name' => $call['function']['name'],
					'input' => $input];
			}
			if (!empty($calls))
				return [
					'type' => 'tool_calls',
					'calls' => $calls];
		}
		return [
			'type' => 'text',
			'text' => $this->text($message)];
	}

	// Plain-text reply extractor. content is normally a string; a few providers
	// return an array of content parts, so coerce that to a flat string.
	protected function text($message) {
		$content = isset($message['content']) ? $message['content'] : '';
		if (is_array($content)) {
			$parts = [];
			foreach ($content as $part) {
				if (is_array($part) && isset($part['text']))
					$parts[] = $part['text'];
				elseif (is_string($part))
					$parts[] = $part;
			}
			$content = implode('', $parts);
		}
		return (string) $content;
	}
}
