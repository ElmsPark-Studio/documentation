<?php
/**
 * PageMotor Architect AI: OpenAI-Compatible Tool Re-wrapper
 *
 * The tool-schema BODY (name / description / JSON-Schema parameters) is identical
 * across Anthropic Messages and OpenAI Chat Completions; only the outer wrapper
 * differs. So this re-wraps the existing PM_AI_Claude schema bodies into the
 * OpenAI `function` shape rather than re-deriving them. create_content_* is still
 * generated dynamically by core from $motor->content->types — we never duplicate
 * that logic, we just reach for its output.
 *
 *   Anthropic: { name, description, input_schema }
 *   OpenAI:    { type: 'function', function: { name, description, parameters } }
 *
 * @package 	PageMotor
 * @subpackage 	PageMotor Architect AI: OpenAI-Compatible Plugin
 * @author		Elmspark
 * @copyright 	Copyright (c) 2026, Elmspark Consultants
 * @license		OpenAttribution
 * @since		0.4
 */
class PM_AI_OpenAI_Tools {

	// The full Architect tool set, in OpenAI function shape. Pulls the neutral
	// schema bodies straight from core's PM_AI_Claude catalogue ($motor->ai->Claude)
	// and re-wraps them — no schema duplication.
	public function tools() {
		global $motor;
		$claude = $motor->ai->Claude;
		$bodies = array_merge(
			$claude->create_content(),
			$claude->create_plugin(),
			$claude->create_theme_template_data());
		return $this->wrap($bodies);
	}

	// Re-wrap a list of Anthropic-shape tool bodies into OpenAI function tools.
	public function wrap($bodies) {
		$tools = [];
		if (empty($bodies) || !is_array($bodies))
			return $tools;
		foreach ($bodies as $tool) {
			if (empty($tool['name']))
				continue;
			$tools[] = [
				'type' => 'function',
				'function' => [
					'name' => $tool['name'],
					'description' => !empty($tool['description']) ? $tool['description'] : '',
					'parameters' => !empty($tool['input_schema']) ? $tool['input_schema'] : [
						'type' => 'object',
						'properties' => (object) []]]];
		}
		return $tools;
	}
}
