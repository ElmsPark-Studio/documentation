/*
Copyright 2026 Elmspark Consultants.
License: OpenAttribution

Generic Architect AI prompt-box handler. Identical in behaviour to the shipped
Claude provider's prompt.js: it posts the trimmed prompt to the active provider's
AJAX handle (the form's 'agent' input = the operator's class name) and renders the
fixed response contract. Nothing here is provider-specific, so one copy serves any
OpenAI-compatible provider.
*/
var prompt_openai;
(function() {
prompt_openai = {
	init: function() {
		if (!pm_prompt.sendButton)
			return;
		// Handle form submission
		pm_prompt.sendButton.addEventListener('click', async function(e) {
			e.preventDefault();
			const prompt = pm_prompt.input.value.trim();
			if (!prompt)
				return;
			// Show loading state
			pm_prompt.responseCanvas.classList.add('active');
			pm_prompt.responseContent.innerHTML = pm_prompt.loading;
			// Disable input while processing
			pm_prompt.input.disabled = true;
			pm_prompt.sendButton.disabled = true;
			// API call
			try {
				var formData = new FormData(pm_prompt.form);
				// The form's 'agent' input holds the active operator's class name, which is its
				// AJAX handle — route straight to it. PM_AI no longer sub-routes by agent.
				formData.set('pm_ajax', formData.get('agent'));	// e.g. Architect_AI_OpenAI
				formData.append('action', 'process');	// Action handled by the agent's process() handler
				formData.append('prompt', prompt);		// Include the trimmed prompt
				const httpResponse = await fetch(window.location.href, {
					method: 'POST',
					body: formData
				});
				if (!httpResponse.ok) {
					throw new Error(`HTTP error! Status: ${httpResponse.status}`);
				}
				const response = await httpResponse.json();
				// Handle successful response
				if (response.success) {
					let resultHTML = '';
					const actions = response.data && response.data.actions;
					if (actions && actions.length > 0) {
						resultHTML = '<div class="pm-ai-result-action">';
						actions.forEach(action => {
							resultHTML += `<div class="pm-ai-success">${action.message}</div>`;
						});
						resultHTML += '</div>';
					}
					else if (response.data && response.data.message)
						resultHTML = `<p>${response.data.message}</p>`;
					pm_prompt.responseContent.innerHTML = resultHTML;
					pm_prompt.input.value = '';
					pm_prompt.charCount.textContent = '0 / 2000';
				}
				else {
					const errorMessage = response.detail && response.detail.message ?
						response.detail.message :
						(response.reason || 'Something went wrong');
					pm_prompt.responseContent.innerHTML =
						`<p class="pm-ai-error">❌ Error: ${errorMessage}</p>`;
				}
			}
			catch (error) {
				// Handle network or other errors
				console.error('Error:', error);
				pm_prompt.responseContent.innerHTML = `
					<p class="pm-ai-error">❌ Failed to process request. Please try again.</p>
					<p>${error.message}</p>`;
			}
			finally {
				// Re-enable input
				pm_prompt.input.disabled = false;
				pm_prompt.input.focus();
				pm_prompt.sendButton.disabled = false;
			}
		});
	}
};
document.addEventListener('DOMContentLoaded', function() {
	prompt_openai.init();
});
})();
