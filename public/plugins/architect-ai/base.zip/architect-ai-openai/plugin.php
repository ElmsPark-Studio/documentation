<?php
/*
Name: PageMotor Architect AI: OpenAI-Compatible
Author: Elmspark
Description: Connect PageMotor's Architect AI agent to any OpenAI-compatible Chat Completions endpoint (DeepSeek, OpenAI/GPT, xAI Grok, Mistral, Groq, OpenRouter, Together, Fireworks, local Ollama/LM Studio/vLLM, and Google Gemini via its OpenAI-compatible endpoint). Editable Base URL + API key + model.
Version: 1.0.1
Requires: 0.4
Class: Architect_AI_OpenAI
Changelog: 1.0.1 - provider HTTP errors (out-of-balance, bad key, rate limit) now surface as plain-English, actionable messages instead of the raw provider JSON.
Docs: https://pagemotor.com/plugins/ai/architect/openai/
License: OpenAttribution

See the PageMotor license.txt file for more information.
*/
/**
 * @package 	PageMotor
 * @subpackage 	PageMotor Architect AI: OpenAI-Compatible Plugin
 * @author		Elmspark
 * @copyright 	Copyright (c) 2026, Elmspark Consultants
 * @license		OpenAttribution
 * @since		0.4
 */

// Adapter (OpenAI Chat Completions request/response mapping) and the tool
// re-wrapper (Claude schema bodies -> OpenAI function shape) live in sibling
// files. __DIR__ resolves to this Plugin folder regardless of how it was loaded.
require_once(__DIR__. '/adapter.php');
require_once(__DIR__. '/tools.php');

class Architect_AI_OpenAI extends PM_Plugin {
	public $title = 'OpenAI-Compatible for Architect AI';
	public $ai = 'OpenAI-Compatible';
	public $agent = 'Architect';
	// This class is BOTH the generic "OpenAI-Compatible" provider (free-text Base
	// URL + Model, for local models and anything not pre-baked) AND the shared base
	// for the curated per-provider family (architect-ai-deepseek / -gpt / -grok /
	// -mistral). A curated subclass sets $default_base_url + a static $models map +
	// a default $model label; that flips the mode in ai_options()/resolve_*() below:
	//   • generic (no $models)  → key + editable Base URL + free-text Model
	//   • curated (has $models) → key only; Base URL fixed, Model via core dropdown
	protected $default_base_url = '';	// curated subclasses set the fixed endpoint
	public $models = [];				// curated subclasses set 'Label' => 'model-id'
	public $model = '';					// curated subclasses set the default $models label
	protected $max_tokens = 8192;

/*---:[ Configuration ]:---*/

	// Core auto-generates the API-key field via _ai_api_key(). The generic provider
	// adds an editable Base URL and a free-text Model; a curated subclass needs
	// neither (Base URL is fixed in $default_base_url, Model comes from the core
	// model dropdown built from $models). Saved under "{$this->_class}_ai".
	public function ai_options() {
		if (!empty($this->models))
			return $this->_ai_api_key();
		return array_merge($this->_ai_api_key(), [
			'base_url' => [
				'type' => 'text',
				'code' => true,
				'label' => 'Base URL',
				'description' => 'OpenAI-compatible endpoint base. Examples: <code>https://api.deepseek.com</code> (DeepSeek), <code>https://api.openai.com/v1</code> (OpenAI), <code>https://api.x.ai/v1</code> (xAI Grok), <code>https://openrouter.ai/api/v1</code> (OpenRouter), <code>http://localhost:11434/v1</code> (Ollama). PageMotor appends <code>/chat/completions</code> automatically.'],
			'model' => [
				'type' => 'text',
				'code' => true,
				'label' => 'Model',
				'description' => 'Model id for this endpoint. Examples: <code>deepseek-v4-flash</code> (DeepSeek), <code>gpt-4o-mini</code> (OpenAI), <code>mistral-large-latest</code> (Mistral). For tool-heavy Architect work, use a model with strong tool-calling (DeepSeek-V4 / GPT-4-class).']]);
	}

	// Resolve the endpoint base: a saved free-text Base URL (generic mode) wins;
	// otherwise the curated subclass's fixed $default_base_url.
	protected function resolve_base_url() {
		if (!empty($this->ai_options['base_url']))
			return $this->ai_options['base_url'];
		return $this->default_base_url;
	}

	// Resolve the model id. Curated mode: map the core dropdown's saved LABEL (stored
	// at "{$this->_class}-model", default $this->model) through $models to an id —
	// the exact pattern the Claude provider uses. Generic mode: the free-text
	// ai_options Model value verbatim.
	protected function resolve_model() {
		global $motor;
		if (!empty($this->models)) {
			$label = !empty($motor->ai->options["{$this->_class}-model"]) ? $motor->ai->options["{$this->_class}-model"] : $this->model;
			if (!empty($this->models[$label]))
				return $this->models[$label];
			return reset($this->models);	// fall back to the first curated model
		}
		return !empty($this->ai_options['model']) ? $this->ai_options['model'] : false;
	}

/*---:[ Prompt JS + UI ]:---*/

	public function register_js() {
		return [
			'prompt-openai' => [
				'url' => ARCHITECT_AI_OPENAI_URL. '/prompt.js',
				'requires' => [
					'pm-prompt']]];
	}

	public function js_prompt() {
		return [
			'prompt-openai'];
	}

	public function prompt() {
		return [
			'title' => 'PageMotor Architect AI',
			'instructions' => 'Ask me to create content (using any Content Type!) or to create a Plugin. (More functionality coming soon.)',
			'prompt' => 'Tell me what you&rsquo;d like to do... (e.g., &lsquo;Create a new Page about national parks in the Rocky Mountains&rsquo;)',
		];
	}

/*---:[ Request building ]:---*/

	// Plain-string system prompt: OpenAI-compatible endpoints take the system text
	// as messages[0].content. (Anthropic wraps it in a cache_control array; that
	// difference is exactly what the adapter isolates.) The doc string itself is
	// reused verbatim from core via PM_AI_Prompts::docs().
	protected function system_prompt() {
		global $motor;
		return
			"You are an AI agent, and your name is Architect AI because you can build anything with PageMotor! ".
			"You can do things like:\n".
			"* Create new Content using any Content Types registered to PageMotor\n".
			"* Create custom Plugins to add specific functionality or perform integrations ".
			"(if you want to do anything in PageMotor with code, Plugins are the way to do it)\n".
			"* Create PageMotor Theme template and instance data to mimic the HTML of any design for rapid prototyping\n".
			$motor->ai->prompts->docs();
	}

/*---:[ AJAX ]:---*/

	public function ajax() {
		return [
			'process' => ['method' => 'ajax_process']];
	}

	public function ajax_process($args = []) {
		if (empty($args['prompt'])) {
			echo json_encode([
				'success' => false,
				'reason' => 'missing_input',
				'detail' => [
					'field' => 'prompt',
					'message' => 'No prompt provided.']]);
			return;
		}
		echo json_encode($this->process(['prompt' => $args['prompt']]));
	}

/*---:[ Orchestration ]:---*/

	// Single-shot (v1): build the request, call the provider, normalise any tool
	// calls, return the fixed response contract the shared prompt JS expects. Tool
	// results are NOT fed back for a follow-up turn (exact parity with the shipped
	// Claude provider). A multi-turn loop is the documented v2.
	public function process($args = []) {
		$prompt = !empty($args['prompt']) ? $args['prompt'] : false;
		if (empty($prompt))
			return [
				'success' => false,
				'reason' => 'missing_input',
				'detail' => [
					'field' => 'prompt',
					'message' => 'No prompt provided.']];
		$key = !empty($this->ai_options['key']) ? $this->ai_options['key'] : false;
		$base_url = $this->resolve_base_url();
		$model = $this->resolve_model();
		if (empty($base_url))
			return [
				'success' => false,
				'reason' => 'missing_config',
				'detail' => [
					'field' => 'base_url',
					'message' => 'No Base URL is configured for this provider. Set it in the AI Agent settings (e.g. https://api.deepseek.com).']];
		if (empty($model))
			return [
				'success' => false,
				'reason' => 'missing_config',
				'detail' => [
					'field' => 'model',
					'message' => 'No Model is configured for this provider. Set it in the AI Agent settings (e.g. deepseek-v4-flash).']];
		$adapter = new PM_AI_OpenAI_Adapter;
		$tools = new PM_AI_OpenAI_Tools;
		$data = $adapter->build_request([
			'model' => $model,
			'max_tokens' => $this->max_tokens,
			'system' => $this->system_prompt(),
			'tools' => $tools->tools(),
			'prompt' => $prompt]);
		try {
			$response = $this->request($data, $base_url, $key);
		}
		catch (Exception $e) {
			return [
				'success' => false,
				'reason' => 'provider_error',
				'detail' => [
					'message' => $e->getMessage()]];
		}
		$parsed = $adapter->parse_response($response);
		// The model was cut off mid-tool-call (truncated arguments JSON). Report the
		// real cause instead of letting an empty payload masquerade as a failed action.
		if ($parsed['type'] === 'truncated')
			return [
				'success' => false,
				'reason' => 'truncated_response',
				'detail' => [
					'finish_reason' => !empty($parsed['finish_reason']) ? $parsed['finish_reason'] : 'length',
					'message' => 'The model&rsquo;s response was cut off before it finished building the action (it most likely hit the token limit), so nothing was created. Try a shorter or simpler request.']];
		// Model called one or more tools: run each once, collect action messages.
		if ($parsed['type'] === 'tool_calls') {
			$actions = [];
			foreach ($parsed['calls'] as $call) {
				$envelope = $this->take_action($call['name'], $call['input']);
				if (!empty($envelope['success']))
					$actions[] = ['message' => $envelope['data']['message'] ?? 'Action completed'];
				else
					$actions[] = ['message' => 'Error: '. ($envelope['detail']['message'] ?? $envelope['reason'] ?? 'Unknown error')];
			}
			return [
				'success' => true,
				'data' => ['actions' => $actions]];
		}
		// Otherwise return the plain text reply.
		return [
			'success' => true,
			'data' => ['message' => $parsed['text']]];
	}

	// Identical dispatch to the Claude provider's take_action(): tool name -> the
	// shared, provider-neutral PM_AI_Actions handler, which returns a locked
	// envelope with ready-to-render HTML.
	protected function take_action($tool, $values) {
		global $motor;
		if ($motor->tools->text->starts_with($tool, 'create_content_'))
			return $motor->ai->actions->create_content(['content' => $values]);
		elseif ($tool == 'create_plugin')
			return $motor->ai->actions->create_plugin(['plugin' => $values]);
		elseif ($tool == 'create_theme_template_data')
			return $motor->ai->actions->create_theme_template_data(['data' => $values]);
		return [
			'success' => false,
			'reason' => 'unknown_tool',
			'detail' => [
				'tool' => $tool,
				'message' => 'Unknown AI tool.']];
	}

/*---:[ HTTP ]:---*/

	// The provider call. Endpoint is derived from the saved Base URL; auth is the
	// OpenAI-standard Bearer header (omitted entirely when no key is set, so local
	// keyless endpoints like Ollama work). No streaming: single-shot curl with a
	// long timeout, matching the Architect agent's existing behaviour.
	protected function request($data, $base_url, $key) {
		set_time_limit(0);
		$endpoint = $this->endpoint($base_url);
		$headers = ['Content-Type: application/json'];
		if (!empty($key))
			$headers[] = 'Authorization: Bearer '. $key;
		$ch = curl_init($endpoint);
		curl_setopt_array($ch, [
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => json_encode($data),
			CURLOPT_HTTPHEADER => $headers,
			CURLOPT_TIMEOUT => 600]);
		$response = curl_exec($ch);
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		$error = curl_error($ch);
		curl_close($ch);
		if ($error)
			throw new Exception("Could not reach $this->ai: $error. Check the Base URL and your connection.");
		if ($httpCode !== 200)
			throw new Exception($this->http_error($httpCode, $response));
		return json_decode($response, true);
	}

	// Turn a provider HTTP error into a plain-English, actionable message instead of
	// dumping the raw JSON at the operator. OpenAI-compatible providers return
	// {"error":{"message":...}}; we surface that plus a hint keyed on the status code.
	// The most common one in practice is 402 (out of balance), which otherwise reads
	// as an opaque "provider error" with no obvious cause.
	protected function http_error($code, $response) {
		$provider = !empty($this->ai) ? $this->ai : 'The provider';
		$decoded = json_decode((string) $response, true);
		$detail = !empty($decoded['error']['message']) ? $decoded['error']['message'] : '';
		$said = $detail ? " Provider said: $detail" : '';
		switch ((int) $code) {
			case 401:
			case 403:
				return "$provider rejected the API key (HTTP $code). Check the key in this provider&rsquo;s Settings.". $said;
			case 402:
				return "Your $provider account is out of balance (HTTP 402). Top it up and try again.". $said;
			case 429:
				return "$provider rate-limited the request (HTTP 429). Wait a moment, or choose a smaller model or a higher account tier.". $said;
			default:
				return "$provider returned an error (HTTP $code).". ($detail ? " $detail" : ' '. substr((string) $response, 0, 300));
		}
	}

	// Resolve the Chat Completions endpoint from a user-entered Base URL. Tolerates
	// a trailing slash and a Base URL that already includes the full path, so all of
	// "https://api.deepseek.com", "https://api.openai.com/v1/", and a pasted full
	// ".../chat/completions" resolve correctly.
	protected function endpoint($base_url) {
		$base = rtrim(trim($base_url), '/');
		if (preg_match('#/chat/completions$#', $base))
			return $base;
		return $base. '/chat/completions';
	}
}
